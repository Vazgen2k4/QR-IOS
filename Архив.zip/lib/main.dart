import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:proweb_qr/ui/app.dart';

Future<void> main() async {
  
  runApp(const ProwebQR());
}

