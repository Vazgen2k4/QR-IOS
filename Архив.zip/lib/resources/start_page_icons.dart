part of 'resources.dart';

class StartPageIcons {
  StartPageIcons._();

  static const String math = 'assets/icons/start_page/math.svg';
  static const String menu = 'assets/icons/start_page/menu.svg';
  static const String qr = 'assets/icons/start_page/qr.svg';
}
