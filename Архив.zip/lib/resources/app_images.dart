part of 'resources.dart';

class AppImages {
  AppImages._();

  static const String arrow = 'assets/images/arrow.png';
  static const String ban = 'assets/images/ban.png';
}
