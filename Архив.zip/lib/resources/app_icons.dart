part of 'resources.dart';

class AppIcons {
  AppIcons._();

  static const String ban = 'assets/icons/ban.svg';
  static const String logo = 'assets/icons/logo.svg';
  static const String profile = 'assets/icons/profile.svg';
  static const String qrCode = 'assets/icons/qr_code.svg';
  static const String telegramm = 'assets/icons/telegramm.svg';
  static const String telegrammMini = 'assets/icons/telegramm_mini.svg';
}
